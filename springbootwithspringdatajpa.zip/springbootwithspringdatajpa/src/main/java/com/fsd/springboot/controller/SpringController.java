package com.fsd.springboot.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.fsd.springboot.model.Book;
import com.fsd.springboot.model.BookDto;
import com.fsd.springboot.model.Subject;
import com.fsd.springboot.service.SpringServiceImpl;

@Controller
public class SpringController {
	
	@Autowired
	SpringServiceImpl springServiceImpl;
	
	 @RequestMapping(value = "/book/add", method = RequestMethod.POST)
	 public String addBook(@ModelAttribute("book") BookDto book) {
		 	Book bookin=new Book();
		 	bookin.setBookId(book.getBookId());
		 	bookin.setTitle(book.getTitle());
		 	bookin.setPrice(book.getPrice());
		 	bookin.setVolume(book.getVolume());
		 	bookin.setPublishDate(book.getPublishDate());
		 	Subject sub=new Subject();
		 	sub.setSubjectId(book.getRefSubjectId());
		 	bookin.setSubject(sub);
		 
	       if(book!=null) {
	    	   springServiceImpl.addBook(bookin);
	       }
	 
	     return "redirect:/books";
	 
	 }
	 
	 @RequestMapping(value = "/books", method = RequestMethod.GET)
	 public String getAllBooks(Model model) throws IOException {
		 List<BookDto> booksResult=new ArrayList<>();
		 
		 List<Book> books=springServiceImpl.getAllBooks();
		 for (Book book : books) {
			 BookDto bookdto= new BookDto();
			 bookdto.setBookId(book.getBookId());
			 bookdto.setTitle(book.getTitle());
			 bookdto.setPrice(book.getPrice());
			 bookdto.setVolume(book.getVolume());
			 bookdto.setPublishDate(book.getPublishDate());
			 bookdto.setRefSubjectId(book.getSubject().getSubjectId());
			 booksResult.add(bookdto);
		 }
		 model.addAttribute("book", new BookDto());
	     model.addAttribute("bookList", booksResult);
	     return "book";
	 }
	 
	 @RequestMapping("/book/remove/{id}")
	 public String deleteBook(@PathVariable("id") long bookId) {
	 
		 springServiceImpl.deleteBook(bookId);
	        return "redirect:/books";
	 }
	 
	 @RequestMapping("/book/find/{id}")
	 public String findBook(@PathVariable("id") int bookId, Model model) {
		 List<BookDto> booksResult=new ArrayList<>();	
		 Book book=null;//springServiceImpl.findBook(bookId);
		 	
		 	BookDto bookdto=new BookDto();
		 	bookdto.setBookId(book.getBookId());
			bookdto.setTitle(book.getTitle());
			bookdto.setPrice(book.getPrice());
			bookdto.setVolume(book.getVolume());
			bookdto.setPublishDate(book.getPublishDate());
		 	bookdto.setRefSubjectId(book.getSubject().getSubjectId());
		 	booksResult.add(bookdto);
		 	model.addAttribute("bookList", booksResult);
	        return "findbook";
	 }
	 
	 @RequestMapping("/book/search")
	 public String searchBookByTitle(HttpServletRequest request, Model model) { 	
		 	List<BookDto> booksResult=new ArrayList<>();
			 String str=request.getParameter("title");
			 System.out.println(str);
			 List<Book> books=springServiceImpl.searchBookByTitle(str);
			 for (Book book : books) {
				 BookDto bookdto= new BookDto();
				 bookdto.setBookId(book.getBookId());
				 bookdto.setTitle(book.getTitle());
				 bookdto.setPrice(book.getPrice());
				 bookdto.setVolume(book.getVolume());
				 bookdto.setPublishDate(book.getPublishDate());
				 bookdto.setRefSubjectId(book.getSubject().getSubjectId());
				 booksResult.add(bookdto);
			 }
		     model.addAttribute("bookList", booksResult);
	        return "findbook";
	 }
	 
	
	 
	 
	 @RequestMapping(value = "/subject/add", method = RequestMethod.POST)
	 public String addSubject(@ModelAttribute("subject") Subject sub) throws IOException {
	       if(sub!=null) {
	    	   springServiceImpl.addSubject(sub);
	       }
	 
	     return "redirect:/subjects";
	 
	 }
	 
	 @RequestMapping(value = "/subjects", method = RequestMethod.GET)
	 public String getAllSubjects(Model model) throws IOException {
		 
		 model.addAttribute("subject", new Subject());
	     model.addAttribute("subjectList", springServiceImpl.getAllSubjects());
	     return "subject";
	 }
	 
	 @RequestMapping("/subject/remove/{id}")
	 public String deleteSubject(@PathVariable("id") long subjectId) {
	 
		 springServiceImpl.deleteSubject(subjectId);
	        return "redirect:/subjects";
	 }
	 
	 @RequestMapping("/subject/find/{id}")
	 public String findSubject(@PathVariable("id") int subjectId, Model model) {
		 	List<Subject> subjects=new ArrayList<>();
		 	subjects.add(null/*springServiceImpl.findSubject(subjectId)*/);
	        model.addAttribute("subjectList", subjects);
	        return "findsubject";
	 }
	 
	 @RequestMapping("/subject/search")
	 public String findSubjectByDurationInHrs(HttpServletRequest request, Model model) {
		 String durationInHours=request.getParameter("durationInHours");
	     model.addAttribute("subjectList", springServiceImpl.findSubjectByDurationInHrs(Integer.valueOf(durationInHours)));
	     return "findsubject";
	 }

}
