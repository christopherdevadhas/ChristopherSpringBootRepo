package com.fsd.springboot.model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="Subject")
public class Subject implements Serializable{
	
	private static final long serialVersionUID = -2666307719424514105L;
	
	private long subjectId;
	private String subtitle;
	private int durationInHours;
	private Set<Book> references=new HashSet<>();
	
	
	@Id
	@Column(name = "SUBJECT_ID", unique = true, nullable = false)
	public long getSubjectId() {
		return subjectId;
	}
	public void setSubjectId(long subjectId) {
		this.subjectId = subjectId;
	}
	
	@Column(name="SUBTITLE")
	public String getSubtitle() {
		return subtitle;
	}
	public void setSubtitle(String subtitle) {
		this.subtitle = subtitle;
	}
	
	@Column(name="DURATION_HRS")
	public int getDurationInHours() {
		return durationInHours;
	}
	public void setDurationInHours(int durationInHours) {
		this.durationInHours = durationInHours;
	}
	
	@OneToMany(mappedBy="subject",fetch = FetchType.LAZY)
	public Set<Book> getReferences() {
		return references;
	}
	public void setReferences(Set<Book> references) {
		this.references = references;
	}
	
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	
	
	
}
