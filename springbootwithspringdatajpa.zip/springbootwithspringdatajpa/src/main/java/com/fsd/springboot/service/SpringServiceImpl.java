package com.fsd.springboot.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.fsd.springboot.dao.SpringDataDao;
import com.fsd.springboot.model.Book;
import com.fsd.springboot.model.Subject;


@Service
public class SpringServiceImpl implements SpringService {
	
	@Autowired
	SpringDataDao springDataDao;

	@Override
	public List<Book> getAllBooks() {
		return springDataDao.getAllBooks();
	}

	@Override
	public void addBook(Book book) {
		springDataDao.insertBook(book);
		
	}

	/*@Override
	public Optional<Book> findBook(long bookId) {
		return springDataDao.findBook(bookId);
	}*/
	
	@Override
	public List<Book> searchBookByTitle(String title){
		return springDataDao.searchBookByTitle(title);
	}
	
	@Override
	public List<Subject> findSubjectByDurationInHrs(int durationInHours){
		return springDataDao.findSubjectByDurationInHrs(durationInHours);
	}

	@Override
	public void deleteBook(long bookId) {
		springDataDao.deleteBook(bookId);
	}

	@Override
	public List<Subject> getAllSubjects() {
		return springDataDao.getAllSubjects();
	}

	@Override
	public void addSubject(Subject sub) {
		springDataDao.insertSubject(sub);
	}

	/*@Override
	public Subject findSubject(long subjectId) {
		return springDataDao.findSubject(subjectId);
	}*/

	@Override
	public void deleteSubject(long subjectId) {
		springDataDao.deleteSubject(subjectId);
	}
	
	
}
