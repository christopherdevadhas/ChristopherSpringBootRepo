package com.fsd.springboot.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.fsd.springboot.model.Book;
import com.fsd.springboot.model.Subject;
import com.fsd.springboot.repository.BookRepository;
import com.fsd.springboot.repository.SubjectRepository;


@Component
public class SpringDataDao {
	
	@Autowired
    BookRepository bookRepository;
	
	@Autowired
	SubjectRepository subjectRepository;
	
	@Transactional
	public void insertSubject(Subject sub){
		subjectRepository.save(sub);
	}
	
	@Transactional
	public void insertBook(Book book){
		bookRepository.save(book);
	}
	
/*	@Transactional
	public Optional<Book> findBook(long bookId){
		return bookRepository.findById(bookId);
	}*/
	
	@SuppressWarnings("rawtypes")
	@Transactional
	public List<Book> searchBookByTitle(String title){
		List<Book> books=new ArrayList<>();
		 
		Iterable bookIterable=bookRepository.findByTitle(title);
			Iterator bookIterator=bookIterable.iterator();
			  while(bookIterator.hasNext())
			  {
				  books.add((Book) bookIterator.next());
			  }
			  
			  for (Book book : books) {
				  System.out.println(book.getBookId()+"|"+book.getTitle());
			  }
			 
			  return books;  
	}
	
	/*@Transactional
	public Optional<Subject> findSubject(long subjectId){
		
		return subjectRepository.findById(subjectId);
	}*/
	
	@SuppressWarnings("rawtypes")
	@Transactional
	public List<Subject> findSubjectByDurationInHrs(int durationInHours){
		
		List<Subject> subjects=new ArrayList<>();
		Iterable subIterable=subjectRepository.findSubjectByDurationInHrs(durationInHours);
		Iterator subIterator=subIterable.iterator();
		  while(subIterator.hasNext())
		  {
			  subjects.add((Subject) subIterator.next());
		  }
		return subjects;
	}
	
	@SuppressWarnings("rawtypes")
	@Transactional
	public List<Subject> getAllSubjects(){
		
		List<Subject> subjects=new ArrayList<>();
		Iterable subIterable=subjectRepository.findAll();
		Iterator subIterator=subIterable.iterator();
		  while(subIterator.hasNext())
		  {
			  subjects.add((Subject) subIterator.next());
		  }
		return subjects;
	}
	
	@SuppressWarnings("rawtypes")
	@Transactional
	public List<Book> getAllBooks(){
		List<Book> books=new ArrayList<>(); 
		
		Iterable bookIterable=bookRepository.findAll();
		Iterator bookIterator=bookIterable.iterator();
		  while(bookIterator.hasNext())
		  {
			  books.add((Book) bookIterator.next());
		  }
		  
		return books;
	}
	
	
	public void deleteSubject(long subjectId){
		subjectRepository.deleteById(subjectId);
	}
	
	public void deleteBook(long bookId){
		bookRepository.deleteById(bookId);
	}


}
