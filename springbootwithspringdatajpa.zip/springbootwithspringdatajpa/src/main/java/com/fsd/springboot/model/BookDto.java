package com.fsd.springboot.model;

import java.io.Serializable;
import java.sql.Date;

public class BookDto implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private long bookId;
	private String title;
	private double price;
	private int volume;
	private Date publishDate;
	private long refSubjectId;
	public long getBookId() {
		return bookId;
	}
	public void setBookId(long bookId) {
		this.bookId = bookId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getVolume() {
		return volume;
	}
	public void setVolume(int volume) {
		this.volume = volume;
	}
	public Date getPublishDate() {
		return publishDate;
	}
	public void setPublishDate(Date publishDate) {
		this.publishDate = publishDate;
	}
	public long getRefSubjectId() {
		return refSubjectId;
	}
	public void setRefSubjectId(long refSubjectId) {
		this.refSubjectId = refSubjectId;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	
	

}
