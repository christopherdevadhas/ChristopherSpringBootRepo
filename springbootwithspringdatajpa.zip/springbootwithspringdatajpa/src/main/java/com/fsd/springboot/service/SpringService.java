package com.fsd.springboot.service;

import java.util.List;
import java.util.Optional;

import com.fsd.springboot.model.Book;
import com.fsd.springboot.model.Subject;

public interface SpringService {
	
	public List<Book> getAllBooks();
	public void addBook(Book book);
	//public Optional<Book> findBook(long bookId);
	public void deleteBook(long bookId);
	public List<Book> searchBookByTitle(String title);
	
	public List<Subject> getAllSubjects();
	public void addSubject(Subject sub);
	//public Optional<Subject> findSubject(long subjectId);
	public void deleteSubject(long subjectId);
	public List<Subject> findSubjectByDurationInHrs(int durationInHours);

}
