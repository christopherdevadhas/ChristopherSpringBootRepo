export class SampleService{
smpls=['test main smpl1','test main smpl2', 'test main smpl3','test main smpl4'];
}