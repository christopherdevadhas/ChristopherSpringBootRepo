export class SampleService{
smpls=['test project smpl1','test project smpl2', 'test project smpl3','test project smpl4'];
}