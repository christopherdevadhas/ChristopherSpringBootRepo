import { Component, OnInit } from '@angular/core';
import { SampleService } from './task-component.service';
import { task } from './task';
@Component({
  selector: 'app-task-component',
  templateUrl: './task-component.component.html',
  styleUrls: ['./task-component.component.css'],
   providers: [ SampleService ]
})
export class TaskComponentComponent implements OnInit {
smpls:string[];
inputtext=null;
sample=null
data:Array<task>=[];

clickAction()
{
	this.sample=this.inputtext
}
  constructor(private sm: SampleService) {
	this.smpls=this.sm.smpls
	  }
getTask()
{
	this.sm.getTask();
	this.data=this.sm.data;
	console.log(this.sm.data);
	console.log(this.data);
}

  ngOnInit() {
  }
  addMore()
  {
	  this.smpls.push(this.inputtext)
		this.inputtext=null;
}
}
