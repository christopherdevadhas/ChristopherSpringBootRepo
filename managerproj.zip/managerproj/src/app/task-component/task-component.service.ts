import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { task } from './task';


@Injectable()
export class SampleService{
	apiAddress:string;
	data:Array<task> = [];
	constructor(private http: HttpClient) { 
	
	this.apiAddress='http://localhost:8080/taskdetails/tasks/';
	}
smpls=['test task smpl1','test task smpl2', 'test task smpl3','test task smpl4'];

getTask() {
 
   this.http.get<Array<task>>(this.apiAddress).subscribe(response => this.data =response);
   
}
}